//console.log("heyyy man");
//document.write("document write");

 //var name ='thrilok';
 //const fname= 'sai';
 //console.log(typeof name);
 //console.log( fname);

  //let num1=10;
  //let num2=2;
//  console.log(num1+num2);
 //console.log(num1**num2);
// alert("Hello");
// window.alert("world");
// let name= prompt("name");
// name.length;
// console.log(name.length);
// console.log(4**4);
// function getMilk(money) {   
//   console.log("leaveHouse");
//   console.log("moveRight");
//   console.log("moveRight");
//   console.log("moveUp");
//   console.log("moveUp");
//   console.log("moveUp");
//   console.log("moveUp");
//   console.log("moveRight");
//   console.log("moveRight");
//   var no= Math.floor( money/3);
//   console.log(`Number of billtes is ${no} milk`);
//   console.log("moveLeft");
//   console.log("moveLeft");
//   console.log("moveDown");
//   console.log("moveDown");
//   console.log("moveDown");
//   console.log("moveDown");
//   console.log("moveLeft");
//   console.log("moveLeft");
//   console.log("enterHouse");
//   return money%3;
// }
// console.log(getMilk(4));

// prompt("name");
// prompt("name2");
// let a= Math.random();
// b=(a*100)+1;
// console.log(Math.floor(b)+1);

// function buzz(s){
 
// var a=1;
// while(a<s){
// if((a%3)!==0&&(a%5)!==0)
// console.log(a);
// else if((a%3===0)&&(a%5)===0)
// console.log("Fizzbuzz");
// else if((a%3===0))
// console.log("Fizz");
// else if((a%5===0))
// console.log("Buzz");
// a++;
//   }

// }
// buzz(30);


// function fizz(){

// let arr=[];
// for(let a=1;a<=25;a++){
//   if((a%3)!==0&&(a%5)!==0)
//  arr.push(a);
//  else if((a%3===0)&&(a%5)===0)
//  arr.push("Fizzbuzz");
//  else if((a%3===0))
//  arr.push("Fizz");
//  else if((a%5===0))
//  arr.push("Buzz");
// //arr.push(a);
// //
// }
// console.log(arr);

// }
// fizz();

// function whosPaying(names) {
    
//   /******Don't change the code above*******/
      
//       //Write your code here.
//       console.log(names.length);
//       let a= (Math.random()*names.length);
//       console.log(a);
      
//       let ba=Math.floor(a);
//       console.log(ba);
//       let b= `${names[ba]} is going to buy lunch today!`;
//       return b;
// }
// let arr=["a","b","v"];
// console.log(arr.length);
// console.log(whosPaying(arr));