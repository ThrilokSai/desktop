// $(document).ready(function(){
//     $("h1").css("color","blue");
// });

//$("h1").css("color","blue");

// $("h1").addClass("big border");
// $("h1").removeClass("big");
// $("h1").text("fgdshkjfgjh");
// $("button").eq(2).text("gkhs");
// //$("button").html("<a href=''>google</a>");
// $("img").attr("src","data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQUAAADBCAMAAADxRlW1AAABhlBMVEX////6+vr/7e3/8fH/fyf/dwb/ehf/dgD/tpL/6d//3Mz/klP/mWD/fSH/nWf/llvv7+/T09Pd3d3Ly8v09PS9vb3o6Oj79/vj4+OpqamdnZ3R0dGtra3FxcWjo6P89fWamprkzeaSkpKKiorcvt717fatx/a1tbXw4/Hv4PBiYmJ+fn7jy+Xtv75xcXH13Nvjmpnz1dT/nUzlq6rdg4Hvx8bHlcvZtdzeweDrtrXE1/nLps7Il8zjpKPgjYvr2Oz/47D/tI2ybrjLqs7DiMfacW/Gnsq6fr/TYV+jVKrbe3lcXFz/w7L///f/v5//5fD/05r/n47/t2f/zdH/eDLT4frl7fy1a7vWrpy0hnDvyrnInorNtKju183NhazEdaK6npKfgHLPTEnWgVL/iD3NqN3/6sX/taj/tH//0sX/xZL/8dz/olv/lGv/0LP/vqb/jiz/qqT/jXb/h1r/khb/slv/16T/f0f/n37/m4zBv+6Xi+ion+u3tOyEd+SPhOZWSNlXkvPyBMcYAAAU/klEQVR4nO1dCYPixpV+JeJjxjuJ0FXikIRAiiQQLWQQAoOQ09Dg6aQncbzxZI/sbrITx87E2RybOJtjj3++r0QfMM202x6OpoevW1BUSaD69Krqq1LVE3AHcBzkDsjl4IADXgJCvmrCXYWkrIjk+fn7RW6Wc0UEBMaIVQWcAhFZYl68SgZQG+xb3/s24kebOe01o0hAkM/D1cVYBC9XJLWhQskRFg8htXq9hjuUedAVQa4ICqgaD0IeQCgRp4Y765hMGQff/vb2svL1IYhAyiUQnQLknRpojpIXSiqLlgqYrAnEUUEXpOWDjo4YLUXGmyAfCTUiVCVNrKiOpoAu8kAwibHwMbKwD4XDQdvnHXAUWShAUanKFSjKWRRgziW0DmSholSWjyrq+IJZlSpQLjnMhqrQKIuZMTEz4suQsfDenrAg4kVVkAVeEwp8TSoQtIEyQQsHglZSZXavQgH05aOyegMPg2JRVKpFrARq4OgyFIoCOEUJBA3TCbLw8V6UCEmp8oJeKJXUvFpyRF7URU0R8nxR5VWZzxd0USzoqqALK66oqF9EEtkRF1OUSlblfvwe4uON5+HVoZREOc9Qwr98trEXWcuX5jHnESXp+rHSFTWKuvyt6rWdDzjg3oPHwoJ1qzftnUdIepk4LOBcKrG9E5FfGfxR/buY6S4c2yRTVVWSl6soNjSUU3mUUHlNqhbzuz7NTUOuNwjQ4XToSZkJVFEnNNSqJBVUVulqqCcdbUW1er9AGiV8PYapPf9cQyFZBZ0HWS1Xy4qOBGj33hSw08RKvT+Ngc96IGpVJzpqJ5AFXi9ISqWMCdqOz3FXkLTqva8TbwHl3tcFB2wEZOF1j6GWsC+WhejUupZqL34g1WtlhVRBwApVcDZ1eltCvl6vo2iyLQr2FMBKwUx98Cyw8W0664E9dkHN1GQeNZSqKZIqEyILkgICG71gTSzoqwb+9gmVegGv6cTuMham7tScPB34A3dqxXHqTQk8pQBCJi7LvA51tSo08jIvVZUKsD8gBXwpiTf/yJ2HcsSjKTy1fMbCbGx5g0kvnlme5fmmPcAkFBRZf4IcletsOCqPGkIvH0lOWWEsABNae88CZLVCPDDt6cRzp2O393PTjcee76YpDMcwHqSgsUwqIohqmdUkKKzKusQ3sOMlQElHVgr8jjPxCnj4Svjxj/HlH7LgP/7Tq33V18Y6WHj21huvgDffxJdH5+FX+aKvjbfeWQcL7zz6xl7j0d+tiYVHb83xJuIN9vbWRcSjLOKtNy72wOBbdwqP1sbCo289mOOfET958OBf/jU8j/i3n2IMC/z0wQV+8uBOAc9+XSx88zzo1OtHBDVT2oU8U4hKGYqyI0O+oAFflnBT5Xr5TvWzvrV+FkijXmLtZdwFkbV6ogBlp8CUcQ2qUoNUMrV8p7ABFkBkebRiOgWJSSSV2UIeLQJq5EgWlcLrwQLJdM90SqGQyShHF5RKQWK2oGGpkIsCbndKG22ChZdALMhfssfOsEUW7vDQwTZZuLvYHAt398pfx+ZY0Es37O6uinSKmpIN19cuo7Z0y3tzLNTqFcyD51tgY4c6HbvYeIKPH90BTR9PPRibkPq4TV0osfElbEL1vF6W8roMUkEBRc+L39W3wsPmWKjWj8oEpr6VuvaMPqZD6lrxZBb3uvZTGFKYekPv2J1iGkCetZuCCI5YlYoADajyDTaHaD70snls0BaYKcDA7qWT3jGdsFtXw3ja9a1jP4UuhYll0hmwASgLeFaJ8EUo5mXGQg0aWoln88K2pK42x8LclAfdGKzBgMZYF0wHZi9OPX/gYzHw7OmYxdLxwJ2PvIKsC1KFDTXVsM/hgKbnoVTc8xIxx3RlPXgjSsWtq6uDXmA4sMBwYIFhpyw4WhWMzuq0ltFejggWwxGXJPjezr2w0zIUvXG7E9k0C2Q8xrYwpSmYtjmwIR6Ah29CNrNFUErQb0LYjwKjHUGQtCFqE9LvYz6bRpILjbBtGEmIKVz4syQgbdy5GQEkOUYTcH1j1Oag2Qaj3Qcu4diXBlEfwnYIYdIn+Vve4dk0C/6AwAyG6ZR0vZkdY6tIJ6iaFmaDjqCVtFsG1zFOjVaQhC0kAvMIxmkLgg7XHGFKEHRwP8x4M+xwmIR20GzlIDGMU4wPmk3kknS4E/Z9SRRFJ8Yo18oltz77jZcId4baaJpO7a6H6qBrg32ceiBdDbKMIOlHSbt5kjtpB+Eo5CA4NXJ9yHWQBbSKkyg0TqNTwJIzIlHUQoqarHT0A5JArgWjMEn6EJyQkzCAHIfURBEyy53OTeNW2DQL3sBCieTDIO7ZKROKYzAHvaulJEZ7FIVhEIVJ2zjtt6CfBAFmqs+BEXFNLkQLx49tNPigFXAYbGaGgrER24kkCZdL+mGYYFlhG+47agLuxo36d8gWbg/jpN26CIc37nheUUYrU5P50jauc/VtX4o7xMIOcWCB4cACw8ZZwCoRZhQ8CnZ3cbITX61J/Q+SXH+umkqF2srDt4NNsxA/HlBzDO7joQ/YVNoDE6Ssy0jYLHHGwGkI/Tbw6i5nCG/cFrq4DSmgXoQ0hol3MW0+A7LQPMGWP7h9o7YRbFxBTyBjgY0zIAsz04VlFlA1tQPuxu7A5rFxW/Cn1EKpRKemO5269mAM0tWMRtS97VZE2u0dD9sf2giGAwsMBxYYDiwwbEU1XcORnof+tc5QzSmv41S+BragmmwLfDueehDHAOWsNcgrEpdwpN9vG2ESALYTbKxJUHY1EXwbqqlrD+0ZdK3xOIYrrRBGxqjTDIKwE0Z9bhR1bj8osnZsQzW5k9Se0qEV2xTyl8oAWUhGUTQKT8NRH0Yht0PNsHFbMKc2HIN9PKYQo4x2LvIaJEkQRgHX7EdRK2kaO1VOW2gjaDcFti7gpYharRvHljaPQ0vJcGCB4TCviWGDc1mcl/Bg2ysixUqNZKNNtcs7Fat8n2wIm5zR07i6P0Z9y7VTy7atlE4HJvgWvUhSzlfp58VGWZR0nUhlGfiCo9arW1tBtVEWrtaX0xgs26Ipk5GeC6lLL8cgSSYYKyDIDagQKPBFrZovSpkrrG1hgywsTv6nPWK5Jgpq6NE0hdSzL9x2gJQNONZIWa2xaUzIQomHKjJQFmBb2BwLSwsg6NAHajM2XBRSJvu/3C+ze4J51hhvBR6cMiFlJ/MktiWskYVnb9+AD29KZHiSbd/5zr/Pw0/Oo7aDZ2tj4RuP3lwH1vMtX/VH17d6bK+xHhYW1lPi5czeLhdGPsoW0b2xuFRyN4smb8B61lMuQNOzJu7n3YsIveCI84bgcp/776pGziZAUxdZKDMtIGigyxWdL+kOlPQ8iLogf3efV1PfCsgCE882spDNb0Y7KDsaX2CioCHWeeYbsbLjc9w85Lk3Q8ZCiV1xvgoVLT9fSViTSObLaJc3qLeDeSfIHozNOQsgFLBvwNR0DZSCDIIugKrf9xLxMoiV7UniA1bgk1+cBz79/kv2+GU25vfJ97ZzPrvB+/91Hnj3nIWzb9Kr1D8iRz/8iIWe99f2k+fdqAWHjrsddjp78r33P8Tr/OSzjIWzJ09y8Mtnb4csxLh4/qvPn9AffvTr/6Dw/DMWuZYbI3KVTe+1B5OLBSKVcllj3UNy1TJs07Pdu7/49W8+hB/86cGnv0UWzn7z2cNv2J88+4x7/uyzT55hP/fs0z89hB9+8b1PfwfIFiavh4X6UYFd/V5vvs46z1RTtaiU9DIqphJqy62qpue/B5a7/wxzn3yBLLz/u1zuDx+dvUPhBx/mcu+ygvCD32Yl4uzvs/0+Ws/PnqsmegzzNfdLqkmus8A2VdPzzzMW3sBe+y+QhT/+HgMhY+GXn2OITaNdYuH5r54FX/qdt4CcaQF6jGUu878gVUlFE/PykmraXlXx/AvMJ17jrF5ktsDez57RLPMZllhAyn63jp89V03jcTpfJwmCQ4gjYjyqJlRPahlV0xYHFf/w+afPPoT3v3j7Ox+y2vHdP739q++fvYv2kIVwh0+evU3/8BE8fxPbkrN33n53fQ3FCmxpVeB1PHxw9gBtgrlkemAw11JY/Z09zOH2cD5z/PlDeM4+whkHDx4+2M1ZHnDfQa9VgFcR1N6n+3evAOIvO7pM2c2IC3z857/QFw+4n6A9sFE4WT0T/NhKuxaN8ePcUzL8+S87PrttAVmwrKkXQ0wt22SGwG5MXbSjf92Hp0msAWxqm0uAscC86Mc0Y2G+LIDS14QFapo2pD51wbbjNAaaBYFko88/+tvrQcIiqNXzdn0OBxywM/BfTRGteMgIL7DHwZG9voEl11421rxyZrheuRZVJVLFkdnzrfYXcv2ocjWFw0KpFFsmtSza6/rUty6pINkgAykXQdarRC8UwakoOpQEVQZR0BpAKls/9/UBWdCurJzphThbROhDD9x0QUdnyJdEoaCqqClFkKuOIBZAFkCssUe97fMdLK28WNJjO2YZ9z3TQz5sy76a1pVNbtMLhSK7qYvKuqRrDtQ09mREviKUgVS2e+JrxXJtN0hp9riA1EU5mbL/S2TVB5Z9VSFz905ingdWmLCoqGLmLXzfYVpYI1iWeb1GPE9ZWVVCmTUMSpZ9svcO4w844FZYNQ/6EuyBl6/FQ3m6N40zKTqB/K7W0q0PZDa0YDD0urNuag1imA6ya98dDmEIg8FsYg2HE4inFp0MLRf3hUbmNbpQVjSJPaqNLK7E3lfQCXTBmsbdgR/Pxse0G2eXHmMxZTjsxfEQFeSx9ZR2wXQnF1OBhRKvyZJ8n1hIh9ZgMvWtoWuDHWdqcQYTOjPx8seDYTp0uzZlE5+oPbMhu7eLLMiaUOF5XUG72P8hahf/Us+2bUqpmdJzxcBi3dTOYNpAUUpiSbF991w9EYnwRFCIqqpEUPf9OUOrMB4Mxrs+hwMO2Dqk66V5pddXQYVsT2X/68AVUI/kxXyx5bTTFbvJmi5kd6jkS9bEe1QbqvV6A+v74TT2jrum9XhM/WOg3a7Zm8xob+oDn7neLIKkN/QKFBoKX6lIStVRju7Rg0zVOjMGNwakAHUiWxkwYc/km7EnsJnDi640Y6HIlsvJql6oZg8ekfd5hPEFqOx5Iaia0mk6tXow86j91PWmZmylPd/2ZiCxiV3gaLpaEyoYUEXMvsMG2Mr3qEjMYaeA4pC9U8/z2FAj009uSs+XToKggJInhI0xC3mSPaVQuEfGcAl39UDSEkj5/tQFBxxwM6i9KgjEA+pfflYVHrjcyuNJLme8/NtzJIhYcjZfeWHS8grPLgK/q9Uo2FtMr+Y0eYt3YTDcu/zcKIgQrp5tG4XNZR8lZNHp3why3IjtBO25W8BztK5TeiTvqPKxZxPfe9r1hjQ2j49n5nG3h6rJTgddGM/mrBxdXKBcJ4KTk04QJX1jdNIOWyPoJyFzddwMR0ar1TGSpEnaHa79QZu0Wm3jpNUGrg25Vp/tFH2QcB08ZgSt9mmn3R6dZiZyMor6o47Rb/1staVtBT1sKS07HkLsxxMfr/2kh6rJGx9TJqSWbAPCCEZJFEbt06DdD0aY3ygJIGhC9DMORgYXnPY7pD+KSAu4BFpoAgEwv9hwynZijqGRgRxjIeq320bI/IEhS6M+FwUj7vaukNcPc+qmsRvHvWN/MOv1uj0rTnvmzHxKzacuHU8oFC/GmHNJyxi1ouZpeBp0Eug3kYFoBAmBZjQyRgYYrTAXoT3AKCSdKDGwIDD36EHUgjZe91ZkdKBldKJO0uwn7WYrh5+5UbPZ5prBaLeef1xUSYRmb/jvuoCf8N0GF6Ncl17NcDCCwECQHGc0m0EHggC4gLB8GgTjsz04CLCqNAL8J4Am3sf6kAsg8wJPAiMHmMgZGQKD1ZbciGOHk9PcaC1z/LeJXLt9u1L8pd1x49wEomS18/ADDtg+7PkgU2ouRgq8akRLVmo0L0uBEWF5J0v1maLs8a17nz0hAbM/xFwdLybUND3sh0vNV7N5GQxRAgVL1Zmu3fKBKHcQqJp60J3C+PHYhhnQ7tAH/WIqQtgP2kb71DhFrdNqRRDOWWi1TiA64aLWKOhDP/pgFLVy0X7XbT1mCwM2zsQ2czJeGHwMRxFw/dOgBSPutN2CTOaAMUJDiPqogMJm0mojUcluPR2uAWnXo+MZ2oFJ08epPTRtcC6mLrJrn7Q7wQhOySjkcq1RJgpOW5zR7+Ta/ZZxijaRsAelNG/6jT2AbRPbpqw3ads2vtH5ukqGbIonh5rmXOtwWT8waBknhOMMTIGLv9ENncp7imbyosrr753sO+CAF8F/NZGjyiSbwCTtsTZaAbVeeMm0LGtFHF9UKtm8Tv5yXqOkb+bEtgq1Xj+6uq6xFdPYGtiWlabDHvWvhtqgwcaaNAGKTq2qlvQq6GUHKgXVOSrvt0hgUOu10lUuLPC8GKjpQsxsIQZ/eYaflkcWFMUBUuQbTlHQ7oktKEu3rGPfInj57Rj7FZZPLfOqWGS+XaWaI2u6roJUgYomSFVZgZq8/7awjNiej4hQNsWNZv8XmGeVSJmbCl5BC+AlIDzBbSenugG4lmX51qplc958Gri/HCvs/xTPAw5YCc9/MWbx9tyft3kquwRTBKwSJJn3hTQF2ycXdeFf/3unp7ZFsNuQvu8OYjvtdd04Tu2f91KozGdo/M+OT25riMGe+pbr2alvMtEEtkkuvV+/Lix4XR/1keulburHPtiD1Ea1BHOHhn/739ekYiDnFQIwbwtsJHpRCFJ4TXyQLMD2bzGz6YAD7iu+4rSZFQuC9GxBqbjXw0712qKvBNaLJPNeJHvQFr2qFue+FoSakPUe2cY6kvjnCFAkVWWv15fDUb0uX37wBj0vjWPbMi2UD6gdrEsdrWVG4/A6OZIrQkMXVa3K3EWz3BdLVY0tt99f1BviVavoebSXumD3oEeyQSb7hf5FQzuSisDnZZC08hHoYp6x0BDyJTYAtb9wFkddvWlsmy4beOxBGrteHF8WCYdZjFqWymIRIPN7WT4iyhHzvgFapYrVw/4Ps9A50utS4Txl9WEiFhO+kgXV/R9xoaZpprjZ13JL/SzFXzmoqGQD8fPZ8vu2PoCswMuTbjgIE1dH7wF2Rf4Bdxb7rfXWhdJrzsJ72evrzsL/ZTS89ixkbipfdxbmvjpfdxbmOLDA8Jqz8P8n0+lqL9Rx5wAAAABJRU5ErkJggg==");
// //$("a").attr("href","https://www.yahoo.com");


// //$("p").attr("class","border");
// //$("p").removeAttr("class", "border");

// $("p").click(function(){
//     $("p").css("color","grey");
// });
// $("button").eq(3).mousedown(function(){
//     $("p").css("color","purple");
// });
// $("button").mouseup(function(){
//     $("p").css("color","yellow");
// });
// $("input").on("mouseover",function(){
//     //console.log(e.key);
//     //$("h1").html(e.key);
//     $("p").css("color","yellow");
// });

// $("h1").before("<button>kafg</button>");
// $("h1").after("<button>kafg</button>");
// $("h1").prepend("<button>kafg</button>");
// $("h1").append("<button>kafg</button>");

// $("button").eq(4).remove();
$("input").on("click",function(){
        //$("p").toggle();
        //$("p").show();
        //$("p").hide();
       // $("p").fadeOut();
        //$("p").fadeIn();
        //$("p").fadeToggle();
        //$("p").slideUp();
        //$("p").slideDown();
        //$("p").slideToggle();
       // $("p").animate({opacity:0.4});
       $("p").slideUp().slide().animate({opacity:0.4});



     });