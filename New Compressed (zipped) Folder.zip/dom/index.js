//alert("happ");
//document.querySelector("h1").innerHTML="Good bye";
//var dom= document.firstElementChild.lastElementChild.firstElementChild;
//dom.innerHTML="<h1>He2222222222lllllo</h1>";
//document.getElementsByClassName("list")[2].innerText="Thrilok";
//document.getElementsByClassName("list")[2].style.color="blue";

//document.getElementsByTagName("li");
document.querySelectorAll(".item a")[0].style.color="yellow";
document.getElementsByTagName("button")[0].style.backgroundColor="yellow";
//document.querySelector("#title").classList.remove("invisible");
//document.querySelector("#title").classList.remove("huge");
document.querySelector("a").getAttribute("href");
document.querySelector("a").setAttribute("href", "https://www.facebook.com");