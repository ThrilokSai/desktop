public Class First{
    public static void main(){
system.out.println("hello");
}}